WEEK 4 POWER BI DASHBOARD PACKAGE

Included:
- cleaned_data.csv: cleaned, import-ready dataset (700 records)
- PowerBI_Theme.json: report color theme
- DAX_Measures.txt: core KPI measures
- Power_Query_M.txt: optional Power Query template (replace the placeholder CSV path)
- summary CSVs by country, segment, product, month and discount band
- Week4_PowerBI_Dashboard_Preview.html: interactive preview with filters
- README.txt: build instructions

BUILD THE NATIVE POWER BI REPORT
1. Open Power BI Desktop.
2. Home > Get data > Text/CSV > select cleaned_data.csv > Load.
3. Check that Date is Date type and numeric fields are numeric.
4. Modeling > New measure: create measures from DAX_Measures.txt one at a time.
5. View > Themes > Browse for themes > choose PowerBI_Theme.json.
6. Suggested layout:
   - KPI cards: Total Sales, Total Profit, Profit Margin %, Total Units Sold, Total Discounts.
   - Bar chart: Sales by Country.
   - Bar chart: Profit by Segment.
   - Bar chart: Sales by Product.
   - Line chart: monthly Sales and Profit.
   - Column chart: Profit by Discount Band.
   - Slicers: Year, Country, Segment, Product, Discount Band.
7. Save your report as Week4_Business_Performance.pbix.

NOTE: A native .pbix file is not created in this environment because Power BI Desktop's proprietary report authoring/runtime is not available here. The interactive HTML preview is a separate preview, not a .pbix file.
